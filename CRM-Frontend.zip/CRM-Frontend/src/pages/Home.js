import "./home.css";
function Home(){
  return(
    <div className="home">
      <center>
      {/* <img src="CRM.png" width="80%"/> */}
      </center>
    </div>
  );
}
export default Home