import React, { useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';

const Aggridtable = () => {

    const columns = [
        { field: 'name', filter:false },
        {field:'age',filter:true}
      ];
      
      const users = [
        { name:'ganesh',age:22 },
        { name:'shiva',age:40 }
      ];
  return (
    <div className={"ag-theme-alpine"} style={{ width: '400px', height: '400px' }}>
        Working
      <AgGridReact columnDefs={columns} rowData={users}
      />
    </div>
  )
}

export default Aggridtable
