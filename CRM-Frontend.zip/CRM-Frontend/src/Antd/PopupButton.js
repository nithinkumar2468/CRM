import React, { useState } from 'react';
import { Button, Modal } from 'antd';

const PopupButton = () => {
  const [visible, setVisible] = useState(false);

  const showModal = () => {
    setVisible(true);
  };

  const handleOk = () => {
    setVisible(false);
  };

  const handleCancel = () => {
    setVisible(false);
  };

  return (
    <>
      <Button type="primary" onClick={showModal}>
        Open Popup
      </Button>
      <Modal
        title="Popup Title"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <p>This is the content of the popup.</p>
      </Modal>
    </>
  );
};

export default PopupButton;