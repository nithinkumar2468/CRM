import Navbar1 from "./Navbar1";
function IssueRaised(){
    return(
        <div>
            <Navbar1/>
            <div class="py-20">
            <center>
                <div class="py-10">
            <img src="images/incident.png"/>
            <h2>Incident raised..!</h2>
            </div>
            </center>
            </div>
        </div>
    );
}
export default IssueRaised;