package com.infinite.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinite.crm.model.OrdersTestingClass;

public interface OrderTestingRepository extends JpaRepository<OrdersTestingClass,Integer>{

}
